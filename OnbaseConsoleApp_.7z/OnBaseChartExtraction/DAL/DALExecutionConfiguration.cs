﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnBaseChartExtraction.DAL
{
    public class DALExecutionConfiguration
    {
        string ConnectionString = string.Empty;
        string DatabaseName;
        public DALExecutionConfiguration(string prmConnectionString, string prmDBName)
        {
            ConnectionString = prmConnectionString;
            DatabaseName = prmDBName;
        }

        public BsonDocument GetConfig_By_Key(string prm_keyname)
        {
            BsonDocument document = new BsonDocument();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<BsonDocument>("ExecutionConfiguration");
                var filterBuilder = Builders<BsonDocument>.Filter;

                var filter = filterBuilder.Eq("keyname", prm_keyname);

                document = collection.Find(filter).FirstOrDefault(); // get the very 1st matching document.
            }
            catch (Exception)
            {
                document = null;
            }
            return document;
        }

        public List<BsonDocument> GetAllConfig()
        {
            List<BsonDocument> documents = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<BsonDocument>("ExecutionConfiguration");
                documents = collection.Find((new BsonDocument())).ToList();
            }
            catch (Exception ex)
            {
                BsonDocument doc = new BsonDocument();
                doc.Add("Status", "fail");
                doc.Add("Message", ex.Message);
                documents.Add(doc);
            }
            return documents;
        }
    }
}
