﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;

namespace OnBaseChartExtraction.DAL
{
    public class DALCommon
    {
        string ConnectionString = string.Empty;
        string DatabaseName;
        string CollectionCognosReportBot = "CognosReportBot";
        string CollectionCognosBatchEncounters = "CognosBatchEncounters";
        string CollectionFacilityMaster = "FacilityMaster";
        string CollectionChartExtractionLog = "ChartExtractionLog";
        public DALCommon(string prmConnectionString, string prmDBName)
        {
            ConnectionString = prmConnectionString;
            DatabaseName = prmDBName;
        }


        public List<BsonDocument> GetExtractionPendingDocuments()
        {
            List<BsonDocument> result = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var CognosReportBot = database.GetCollection<BsonDocument>(CollectionCognosReportBot);
                var filterBuilder = Builders<BsonDocument>.Filter;
                // SELECT * FROM CognosReportBot
                // WHERE Status != 'Lock'
                // AND Status != 'Error'
                // AND ChartAuditingStatus = 'Pending'
                // AND ChartExtractionStatus = 'Pending'
                // Note: Status should not be equal to Lock OR Error. It means it is still in extraction mode. 'Completed'/'Pending' status can be considered.
                //       ChartAuditingStatus should be pending. It means 
                var filter = filterBuilder.Ne("Status", "Lock") & filterBuilder.Ne("Status", "Error") & filterBuilder.Ne("Status", "Terminated") & filterBuilder.Eq("ChartsAuditingStatus", "Pending") & filterBuilder.Eq("ChartExtractionStatus", "Pending");
                result = CognosReportBot.Find(filter).ToList<BsonDocument>();
            }
            catch (Exception ex)
            {
                result = new List<BsonDocument>();
            }
            return result;
        }

        public bool LockChartExtractionStatus(string TESBatchNo, string ChartExtractionStatus)
        {
            bool IsChartExtractionStatusLocked = false;
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var CognosReportBot = database.GetCollection<BsonDocument>(CollectionCognosReportBot);
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Eq("BatchNumber", TESBatchNo);
                var update = Builders<BsonDocument>.Update.Set("ChartExtractionStatus", ChartExtractionStatus);
                CognosReportBot.UpdateOne(filter, update);
                IsChartExtractionStatusLocked = true;
            }
            catch (Exception ex)
            {
                IsChartExtractionStatusLocked = false;
            }
            return IsChartExtractionStatusLocked;
        }

        /// <summary>
        /// Finalize the TESBatch in the CognosReportBot whether all the charts were completely extracted or there was an error.
        /// </summary>
        /// <param name="TESBatchNo">BatchNumber in CognosReportBot table.</param>
        /// <param name="ChartExtractionStatus">Completed: when all the charts extracted. Error, otherwise.</param>
        /// <param name="OnBaseChartCount">Total number of actual charts extracted from an OnBase. 0, otherwise.</param>
        /// <returns></returns>
        public bool FinalizeCognosReportBatch(string TESBatchNo, string ChartExtractionStatus, int OnBaseChartCount, string Remarks)
        {
            bool IsFinalizeCognosReportBatch = false;
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var CognosReportBot = database.GetCollection<BsonDocument>(CollectionCognosReportBot);
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Eq("BatchNumber", TESBatchNo);
                var update = Builders<BsonDocument>.Update.Set("ChartExtractionStatus", ChartExtractionStatus).Set("OnBaseChartCount", OnBaseChartCount).Set("Remarks", Remarks);
                CognosReportBot.UpdateOne(filter, update);
                IsFinalizeCognosReportBatch = true;
            }
            catch (Exception ex)
            {
                IsFinalizeCognosReportBatch = false;
            }
            return IsFinalizeCognosReportBatch;
        }

        public bool CPTCodesExtracted(string TESBatchNo, string EncounterNo)
        {
            bool IsCPTCodesExtracted = false;
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var CPTCodes = database.GetCollection<BsonDocument>("CPTCodesDetails");
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Eq("TESBatchNo", TESBatchNo) & filterBuilder.Eq("EncounterNo", EncounterNo);
                var document = CPTCodes.Find(filter).FirstOrDefault();
                if (document != null)
                {
                    IsCPTCodesExtracted = true;
                }
            }
            catch (Exception)
            {
                IsCPTCodesExtracted = true;
            }
            return IsCPTCodesExtracted;
        }

        public bool AddCognosBatchEncounter(BsonDocument Data)
        {
            bool IsAddedCognosBatchEncounter = false;
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var CognosBatchEncounters = database.GetCollection<BsonDocument>(CollectionCognosBatchEncounters);
                CognosBatchEncounters.InsertOne(Data);
                IsAddedCognosBatchEncounter = true;
            }
            catch (Exception ex)
            {
                IsAddedCognosBatchEncounter = false;
            }
            return IsAddedCognosBatchEncounter;
        }

        public List<BsonDocument> GetFacilityMasterWithDocTypes()
        {
            List<BsonDocument> result = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var FacilityMaster = database.GetCollection<BsonDocument>(CollectionFacilityMaster);
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.SizeGt("DocTypes", 0);
                result = FacilityMaster.Find(filter).ToList<BsonDocument>();
            }
            catch (Exception ex)
            {
                result = new List<BsonDocument>();
            }
            return result;
        }

        public List<BsonDocument> GetBatchTypeKeyWordSearchConfig()
        {
            List<BsonDocument> result = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var BatchTypeKeyWordSearchConfig = database.GetCollection<BsonDocument>("BatchTypeKeyWordSearchConfig");
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Eq("Active", 1);
                result = BatchTypeKeyWordSearchConfig.Find(filter).ToList<BsonDocument>();
            }
            catch (Exception ex)
            {
                result = new List<BsonDocument>();
            }
            return result;
        }

        public List<BsonDocument> GetDocTypeConfig()
        {
            List<BsonDocument> result = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var DocTypeConfig_onbase = database.GetCollection<BsonDocument>("DocTypeConfig_onbase");
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Gt("RetrivalPreference", 0);
                result = DocTypeConfig_onbase.Find(filter).ToList<BsonDocument>();
            }
            catch (Exception ex)
            {
                result = new List<BsonDocument>();
            }
            return result;
        }

        public List<BsonDocument> GetKeyWordTypeConfig(int DocTypeID)
        {
            List<BsonDocument> result = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var KeyWordTypeConfig = database.GetCollection<BsonDocument>("KeyWordTypeConfig");
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Gt("DocTypeID", DocTypeID);
                result = KeyWordTypeConfig.Find(filter).ToList<BsonDocument>();
            }
            catch (Exception ex)
            {
                result = new List<BsonDocument>();
            }
            return result;
        }

        public List<BsonDocument> GetColumnsListForCognosBatch(int DocTypeID)
        {
            List<BsonDocument> result = new List<BsonDocument>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var KeyWordTypeConfig = database.GetCollection<BsonDocument>("KeyWordTypeConfig");
                var filterBuilder = Builders<BsonDocument>.Filter;
                var filter = filterBuilder.Eq("DocTypeID", DocTypeID) & filterBuilder.Eq("IsSaveToCognosBatch", true);
                result = KeyWordTypeConfig.Find(filter).ToList<BsonDocument>();
            }
            catch (Exception ex)
            {
                result = new List<BsonDocument>();
            }
            return result;
        }

        public void WriteLog(BsonDocument LogDocument)
        {
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var ChartExtractionLog = database.GetCollection<BsonDocument>(CollectionChartExtractionLog);
                ChartExtractionLog.InsertOne(LogDocument);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Use this method to change the column's double value to int.
        /// Just change the table-name and column names.
        /// </summary>
        public void ConvertFloatToInt()
        {
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var KeyWordTypeConfig = database.GetCollection<BsonDocument>("KeyWordTypeConfig");
                var filterBuilder = Builders<BsonDocument>.Filter;
                var docs = KeyWordTypeConfig.Find(new BsonDocument()).ToList<BsonDocument>();
                foreach (var item in docs)
                {
                    ObjectId _id = item["_id"].AsObjectId;
                    int KeywordTypeID = Convert.ToInt32(item["KeywordTypeID"].AsDouble);
                    int DocTypeID = Convert.ToInt32(item["DocTypeID"].AsDouble);
                    var filter = filterBuilder.Eq("_id", _id);
                    var update = Builders<BsonDocument>.Update.Set("KeywordTypeID", KeywordTypeID).Set("DocTypeID", DocTypeID);
                    KeyWordTypeConfig.UpdateOne(filter, update);
                }


            }
            catch (Exception ex)
            {

            }
        }

    }
}
