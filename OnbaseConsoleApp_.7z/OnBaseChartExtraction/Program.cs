﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnBaseChartExtraction.BAL;
using Hyland.Unity;
using System.IO;

namespace OnBaseChartExtraction
{
    class Program
    {
        private string CurrentUser = string.Empty;
        private string URL = string.Empty;
        private string LoginID = string.Empty;
        private string Password = string.Empty;
        private string DataSource = string.Empty;
        private long institutionID = 123456;
        Hyland.Unity.Application app;

        public Hyland.Unity.Application OnBaseAppObj { get; set; }

        public string PathToSaveCharts { get; set; }

        static void Main1(string[] args)
        {
            string OnBaseLiveURL = "http://208.84.217.118/AppServer64AA/service.asmx";
            string OnBaseLiveLoginID = "SRV_IOPTIFY";
            string password = "iOptify06032019";
            string ds = "onbase";
            Hyland.Unity.Application app1;
            try
            {
                OnBaseAuthenticationProperties props = Hyland.Unity.Application.CreateOnBaseAuthenticationProperties(OnBaseLiveURL, OnBaseLiveLoginID, password, ds);
                props.LicenseType = LicenseType.Default;
                props.InstitutionID = 123456;
                app1 = Hyland.Unity.Application.Connect(props);
            }
            catch (Exception)
            {
                app1 = null;
            }

            if (app1 != null)
            {
                string[] lines = "connected".Split('0');
                System.IO.File.WriteAllLines(@"E:\OnBase\status.txt", lines);
                app1.Disconnect();
            }
            else
            {
                string[] lines = "not-connected".Split('0');
                System.IO.File.WriteAllLines(@"E:\OnBase\status.txt", lines);
            }

        }

        static void Main(string[] args)
        {
            Program program = new Program();
            if (program.GetBasicConfig() == -1)
            {
                Environment.Exit(-1);
            }
            else
            {
                BsonDocument ChartExtractionLogDoc = new BsonDocument();
                BsonArray LogSequenceList = new BsonArray();
                BALCommon Obj = new BALCommon();
                BALExecutionConfiguration BALExecutionConfigurationObj = new BALExecutionConfiguration();
                List<BsonDocument> BatchTypeKeyWordSearchConfig = new List<BsonDocument>();
                List<BsonDocument> DocTypeConfig = new List<BsonDocument>();
                List<BsonDocument> KeyWordTypeConfig = new List<BsonDocument>();
                string PathToSaveCharts = System.Configuration.ConfigurationManager.AppSettings["PathToSaveCharts"];// @"\\10.202.5.34\pdf_share\Today\";  // @"E:\OnBase\OnBaseChartExtraction\OnBaseChartExtraction\Uploads\";

                try
                {
                    List<BsonDocument> PendingDocuments = Obj.GetExtractionPendingDocuments();
                    List<BsonDocument> FacilityMasterWithDocTypesList = Obj.GetFacilityMasterWithDocTypes();

                    program.ConnectOnBase();
                    if (program.OnBaseAppObj != null)
                    {
                        // DocumentTypeList dtl1 = program.OnBaseAppObj.Core.DocumentTypes;

                        BsonDocument PendingDocument = new BsonDocument();

                        // Keep getting the first pending TESBatch from the database based on TransitionDate in ascendening order.
                        while ((PendingDocument = Obj.GetFirstExtractionPendingDocument()) != null)
                        {
                            BatchTypeKeyWordSearchConfig = Obj.GetBatchTypeKeyWordSearchConfig();
                            DocTypeConfig = Obj.GetDocTypeConfig();
                            DocTypeConfig = DocTypeConfig.OrderBy(row => row["RetrivalPreference"]).ToList<BsonDocument>();

                            foreach (var each_pending_document in PendingDocuments)
                            {
                                string BatchType = each_pending_document["BatchType"].AsString;
                                string BatchNumber = each_pending_document["BatchNumber"].AsString;
                                string Facility = each_pending_document["FacilityName"].AsString;
                                var DocTypeList = FacilityMasterWithDocTypesList.Where(row => row["FacilityName"] == Facility).ToList().Select(row => row["DocTypes"].AsBsonArray).ToList();

                                Console.WriteLine("Batch:" + BatchNumber);

                                // For the above BatchNumber, change the ExtractionStatus to 'Locked' so that no other instance of this application can pick up the same batch.
                                bool IsChartExtractionStatusLocked = Obj.LockChartExtractionStatus(BatchNumber);

                                #region [If the above Batch-Number has successfully been updated as 'Locked', proceed with the extraction.]
                                if (IsChartExtractionStatusLocked)
                                {
                                    int BatchTypeID = 0;
                                    var docTemp = BatchTypeKeyWordSearchConfig.Where(row => row["BatchType"].AsString == BatchType.Trim()).FirstOrDefault();

                                    if (docTemp != null)
                                    {
                                        BatchTypeID = docTemp["KeyWordTypeID"].AsInt32;
                                    }
                                    else
                                    {
                                        throw new Exception("KeyWordTypeID not found for Batch-Type:" + BatchType);
                                    }

                                    bool ContinueChartExtraction = BALExecutionConfigurationObj.GetConfig_By_Key("ContinueChartExtraction")["value"].AsBoolean;

                                    #region [If the configuration says that chart extraction should continue, then the value must be 'true' else 'false'.]
                                    if (ContinueChartExtraction)
                                    {
                                        #region [Document level exception handling.]
                                        int OnBaseChartCount = 0;
                                        try
                                        {
                                            // create a keyword for BatchNumber. e.g. if ID==119, it means, COMMERCIAL. if ID==120, it means MEDICARE.
                                            List<KeywordType> searchKeywordTypeList = program.OnBaseAppObj.Core.KeywordTypes.Where(r => r.ID == Convert.ToInt32(BatchTypeID)).ToList(); // 119=>TES Batch No Comm , 120=>TES Batch No Med
                                            Keyword keyword = searchKeywordTypeList[0].CreateKeyword(BatchNumber);

                                            int DocTypeID = 0;
                                            // SELECT TOP 1 RetrivalPreference FROM DocTypeConfig WHERE RetrivalPreference == 1;
                                            docTemp = DocTypeConfig.Where(row => row["RetrivalPreference"].AsInt32 == 1).FirstOrDefault();
                                            if (docTemp != null)
                                            {
                                                DocTypeID = docTemp["OnBaseDocTypeID"].AsInt32;
                                            }
                                            else
                                            {
                                                throw new Exception("OnBaseDocTypeID not found for RetrivalPreference '1'.");
                                            }

                                            List<DocumentType> dtl = program.OnBaseAppObj.Core.DocumentTypes.Where(row => row.ID == DocTypeID).ToList();  // get 'CHT-Control Doc V2'
                                            DocumentQuery dq = program.OnBaseAppObj.Core.CreateDocumentQuery().AddDocumentType(dtl[0]).AddKeyword(keyword);  // query in OnBase for the above document and keyword we have created.

                                            long maxDocuments = dq.ExecuteCount();  // total documents for this batch number.
                                            OnBaseChartCount = (int)maxDocuments;

                                            DocumentList docList = dq.Execute(maxDocuments);
                                            //string ChartExtractionStatus = "Pending"; Commented by Rajesh R 21082019
                                            int ChartExtractionCount = 0;
                                            foreach (Document document in docList)
                                            {
                                                // create a new object to create a new log.
                                                ChartExtractionLogDoc = new BsonDocument();

                                                // Log:Add BatchNumber and StartDate to the BsonDocument.
                                                ChartExtractionLogDoc.Add("BatchNumber", BatchNumber);
                                                ChartExtractionLogDoc.Add("StartDate", DateTime.Now);

                                                // Log:Fetch the first pending TESBatchNo.
                                                LogSequenceList.Add(1);

                                                string name = document.DocumentType.Name;
                                                string DocID = document.ID.ToString();

                                                // Log:Fetch the DocumentID.
                                                LogSequenceList.Add(2);

                                                if (document.KeywordRecords.Count > 0)
                                                {
                                                    #region [Read/query all the keywords from OnBase which are required to get saved in CognosBatchEncounter table]
                                                    var CognosBatchColumnNameList = Obj.GetColumnsListForCognosBatch(DocTypeID);

                                                    // Log:Fetch CognosBatchColumnNameList from the Database and prepare BsonDocument to match the CognosBatchEncounter table's structure.
                                                    LogSequenceList.Add(3);

                                                    BsonDocument InsertDocForCognos = new BsonDocument();
                                                    foreach (var item in CognosBatchColumnNameList)
                                                    {
                                                        try
                                                        {
                                                            var KeywordResultList1 = document.KeywordRecords[0].Keywords.Where(row => row.KeywordType.ID == item["KeywordTypeID"].AsInt32).ToList();
                                                            var value = KeywordResultList1[0].Value.ToString();
                                                            InsertDocForCognos.Add(item["CognosBatchColumnName"].AsString, value);
                                                        }
                                                        catch (Exception ex)
                                                        {
                                                            // do nothing.
                                                        }
                                                    }
                                                    #endregion

                                                    #region [Add extra fields to the BsonDoc to bring it in the format of CognosBatchEncounter table.]
                                                    InsertDocForCognos.Add("DocID", DocID);
                                                    InsertDocForCognos.Add("AstProviderNo", "");
                                                    InsertDocForCognos.Add("AstProvider", "");
                                                    InsertDocForCognos.Add("EntryUser", "System");
                                                    InsertDocForCognos.Add("EntryDateTime", DateTime.Now);
                                                    InsertDocForCognos.Add("ProcedureCode", (new BsonArray()));
                                                    InsertDocForCognos.Add("ProcedureDesc", (new BsonArray()));
                                                    InsertDocForCognos.Add("HostName", Environment.MachineName);
                                                    InsertDocForCognos.Add("LockedBy", "");
                                                    InsertDocForCognos.Add("ChartExtractedBy", "System");
                                                    InsertDocForCognos.Add("ChartExtractionDateTime", DateTime.Now);
                                                    InsertDocForCognos.Add("ChartExtractionHostName", Environment.MachineName);
                                                    InsertDocForCognos.Add("RemarksUpdatedOn", DateTime.Now);
                                                    InsertDocForCognos.Add("iOptifyLoadStatus", "Pending");
                                                    InsertDocForCognos.Add("ErrorCounter", "0");

                                                    // Log:Add other fields to the BsonDocument e.g. CreatedBy, CreatedOn etc.
                                                    LogSequenceList.Add(4);
                                                    #endregion

                                                    #region [Query the Encounter No. keyword type from OnBase and get its value]
                                                    var KeywordResultList = document.KeywordRecords[0].Keywords.Where(row => row.KeywordType.ID == 222).ToList();  // Encounter

                                                    // Log:Query OnBase to read EncounterNumber.
                                                    LogSequenceList.Add(5);

                                                    string EncounterNo = "";
                                                    if (KeywordResultList.Count > 0)
                                                    {
                                                        EncounterNo = KeywordResultList[0].Value.ToString();
                                                        ChartExtractionLogDoc.Add("EncounterNo", EncounterNo);

                                                        #region [Query the Facility-Account-No keyword in the OnBase, get its value then get the Physician documents and try to download it.]
                                                        KeywordResultList = document.KeywordRecords[0].Keywords.Where(row => row.KeywordType.ID == 121).ToList();  // FacAccNo
                                                        if (KeywordResultList.Count > 0)
                                                        {
                                                            string FacAccNo = KeywordResultList[0].Value.ToString();
                                                            List<KeywordType> searchKeywordTypeList_facAccNo = program.OnBaseAppObj.Core.KeywordTypes.Where(r => r.ID == 121).ToList(); // 121=>facility accunt no.
                                                            Keyword keyword_facAccNo = searchKeywordTypeList_facAccNo[0].CreateKeyword(FacAccNo);

                                                            // Log:Create Keyword to read FacilityAccountNumber from OnBase.
                                                            LogSequenceList.Add(7);

                                                            // iterate thru each doc-type which we have extracted from the FacilityMaster.
                                                            foreach (var each_doc_type in DocTypeList)
                                                            {
                                                                var each_doc_type_details = DocTypeConfig.Where(row => row["OnBaseDocTypeID"].AsInt32 == Convert.ToInt32(each_doc_type[0].ToString())).FirstOrDefault();
                                                                string each_doc_type_name = each_doc_type_details["OnBaseDocTypeDescription"].AsString;
                                                                string each_doc_type_file_extension = each_doc_type_details["FileExtension"].AsString;

                                                                // query OnBase searching for each doc-type and facility account number.
                                                                List<DocumentType> dtl_phy = program.OnBaseAppObj.Core.DocumentTypes.Where(row => row.ID == Convert.ToInt32(each_doc_type[0].ToString())).ToList();
                                                                DocumentQuery dq_phy = program.OnBaseAppObj.Core.CreateDocumentQuery().AddDocumentType(dtl_phy[0]).AddKeyword(keyword_facAccNo);

                                                                // Log:Query OnBase to fetch physician document type by searching the FacilityAccountNumber.
                                                                LogSequenceList.Add(8);

                                                                maxDocuments = dq_phy.ExecuteCount();  // total documents in the batch.
                                                                DocumentList docList_phy = dq_phy.Execute(maxDocuments);

                                                                // Log:Get the ExecuteCount after executing the query.
                                                                LogSequenceList.Add(9);

                                                                Stream stream;  // = app.Core.Retrieval.PDF.GetDocument(document.DefaultRenditionOfLatestRevision).Stream;

                                                                #region [Download Charts 'pdf','htm' etc.. and save it to the Server's shared drive]
                                                                BsonArray ChartsExtracted = new BsonArray();
                                                                try
                                                                {
                                                                    int DocDownloadCount = 0;
                                                                    foreach (Document document_phy in docList_phy)
                                                                    {
                                                                        bool InValidChartExtension = false;
                                                                        string ChartDocID = document_phy.ID.ToString();
                                                                        string MimeType = document_phy.DefaultRenditionOfLatestRevision.FileType.MimeType;
                                                                        string ChartExtension = "";
                                                                        if (MimeType.ToLower().IndexOf("pdf") >= 0)
                                                                        {
                                                                            ChartExtension = "pdf";
                                                                        }
                                                                        else if (MimeType.ToLower().IndexOf("htm") >= 0)
                                                                        {
                                                                            ChartExtension = "html";
                                                                        }
                                                                        else
                                                                        {
                                                                            InValidChartExtension = true;
                                                                        }

                                                                        // if any other chart extension found (doc,xls, etc), then do not download.
                                                                        if (!InValidChartExtension)
                                                                        {
                                                                            // check the current document's extension and create the stream accordingly.
                                                                            if (ChartExtension.ToLower() == "pdf")
                                                                            {
                                                                                stream = program.OnBaseAppObj.Core.Retrieval.PDF.GetDocument(document_phy.DefaultRenditionOfLatestRevision).Stream;
                                                                                // in the server's shared folder, check if there is a folder with the TESBatchNo. if no, create it.
                                                                                if (!Directory.Exists(PathToSaveCharts + BatchNumber))
                                                                                {
                                                                                    Directory.CreateDirectory(PathToSaveCharts + BatchNumber);
                                                                                }
                                                                                string ChartName = DocID + "_" + ChartDocID + "_" + document_phy.DocumentType.ID.ToString();     // create naming convention like '526620844_526616377_16'.

                                                                                string fullPath = String.Format("{0}.{1}", (PathToSaveCharts + BatchNumber) + "/" + ChartName, ChartExtension);
                                                                                Utility.WriteStreamToFile(stream, fullPath);

                                                                                // Log:Download each physican document and save it to the Server's shared folder.
                                                                                LogSequenceList.Add(10);

                                                                                ChartsExtracted.Add((BsonValue)ChartName);

                                                                                DocDownloadCount++;
                                                                                //ChartExtractionCount++; Commented by Rajesh R 21082019
                                                                            }
                                                                            else
                                                                            {
                                                                                ChartExtractionCount = 0;
                                                                                // *** commented this code. needs to download only PDF.
                                                                                // *** Total Number of PDFs for a batch will be greater than the encounters in teh batch as sometimes one encounter can have multiple PDFs attached to it.
                                                                                // stream = program.OnBaseAppObj.Core.Retrieval.Default.GetDocument(document_phy.DefaultRenditionOfLatestRevision).Stream;
                                                                            }
                                                                        }
                                                                    }
                                                                    if (DocDownloadCount > 0)
                                                                    {
                                                                        InsertDocForCognos.Add("EncounterExtractionStatus", "Completed");
                                                                        InsertDocForCognos.Add("Remarks", "NA");
                                                                        InsertDocForCognos.Add("ChartsExtracted", ChartsExtracted);

                                                                        // Log:Download documents count greater than 0.
                                                                        LogSequenceList.Add(11);
                                                                    }
                                                                    else
                                                                    {
                                                                        InsertDocForCognos.Add("EncounterExtractionStatus", "Error");
                                                                        InsertDocForCognos.Add("Remarks", "Invalid download extension found.");
                                                                        InsertDocForCognos.Add("ChartsExtracted", (new BsonArray()));

                                                                        // Log:Download documents count is 0. Invalid download extension found.
                                                                        LogSequenceList.Add(12);
                                                                    }

                                                                    // Log:Add additional columns to the CognosBatchEncounter's matching BsonDocument.
                                                                    LogSequenceList.Add(13);
                                                                }
                                                                catch (Exception ex)
                                                                {
                                                                    InsertDocForCognos.Add("Status", "Error");
                                                                    InsertDocForCognos.Add("Remarks", "Error in download:" + ex.Message);
                                                                    ChartsExtracted = new BsonArray();
                                                                    InsertDocForCognos.Add("ChartsExtracted", ChartsExtracted);

                                                                    // Log:Exception while downloading the physician document.
                                                                    LogSequenceList.Add(14);
                                                                    //ChartExtractionCount = 0; Commented by Rajesh R 21082019
                                                                }
                                                                #endregion
                                                            }
                                                            Obj.AddCognosBatchEncounter(InsertDocForCognos);

                                                            // Log:Add the BsonDocument to the CognosBatchEncounter table.
                                                            LogSequenceList.Add(15);
                                                        }
                                                        #endregion
                                                    }
                                                    else
                                                    {
                                                        // Log:Exception:No EncounterNumber found.
                                                        LogSequenceList.Add(6);
                                                    }
                                                    #endregion
                                                }
                                                ChartExtractionLogDoc.Add("LogSequence", LogSequenceList);
                                                ChartExtractionLogDoc.Add("EndDate", DateTime.Now);
                                                Obj.WriteLog(ChartExtractionLogDoc);
                                                LogSequenceList = new BsonArray();
                                            }
                                            // Commented by Rajesh Rajamani 21-08-2019
                                            //if (ChartExtractionCount == OnBaseChartCount)
                                            //{
                                            //    //
                                            //}
                                            string ChartExtractionStatus = "Completed";
                                            string Remarks = "NA";
                                            Obj.FinalizeCognosReportBatch(BatchNumber, ChartExtractionStatus, OnBaseChartCount, Remarks);
                                            ChartExtractionCount = 0; // reset.
                                        }
                                        catch (Exception ex)
                                        {
                                            string ChartExtractionStatus = "Error";
                                            string Remarks = ex.Message;
                                            Obj.FinalizeCognosReportBatch(BatchNumber, ChartExtractionStatus, OnBaseChartCount, Remarks);
                                        }
                                        #endregion
                                    }
                                    else
                                    {
                                        Console.WriteLine("Application has been forced to stop.");
                                        break;
                                    }
                                    #endregion
                                }
                                break; // Uncommented for Testing 
                                #endregion
                            }
                        }

                        // When no more pending TESBatch's in the database, disconnect from the OnBase.
                        program.DisconnectOnBase();
                    }
                    ChartExtractionLogDoc.Add("EndDate", DateTime.Now);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Uknown exception:" + ex.Message);
                    Console.WriteLine("Application terminated");
                    program.DisconnectOnBase();
                }
            }
        }

        /// <summary>
        /// Gets the OnBase URL and its credentials from the Config.
        /// </summary>
        /// <returns></returns>
        int GetBasicConfig()
        {
            CurrentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            BALExecutionConfiguration BALExecutionConfigurationObj = new BALExecutionConfiguration();
            BsonDocument docConfig = BALExecutionConfigurationObj.GetConfig_By_Key("OnBaseLiveURL");

            // get the OnBase URL from the Exec-config.
            if (docConfig == null)
            {
                Console.WriteLine("OnBase URL not found in the system. Application terminated.");
                return -1;
            }
            else
            {
                URL = docConfig["value"].AsString;
            }

            // get the OnBase LoginID from the Exec-config.
            docConfig = BALExecutionConfigurationObj.GetConfig_By_Key("OnBaseLiveLoginID");
            if (docConfig == null)
            {
                Console.WriteLine("OnBase LoginID not found in the system. Application terminated.");
                return -1;
            }
            else
            {
                LoginID = docConfig["value"].AsString;
            }

            // get the OnBase Password from the Exec-config.
            docConfig = BALExecutionConfigurationObj.GetConfig_By_Key("OnBaseLivePassword");
            if (docConfig == null)
            {
                Console.WriteLine("OnBase password not found in the system. Application terminated.");
                return -1;
            }
            else
            {
                Password = docConfig["value"].AsString;
            }

            // get the OnBase DataSource from the Exec-config.
            docConfig = BALExecutionConfigurationObj.GetConfig_By_Key("OnBaseLiveDataSource");
            if (docConfig == null)
            {
                Console.WriteLine("OnBase data source not found in the system. Application terminated.");
                return -1;
            }
            else
            {
                DataSource = docConfig["value"].AsString;
            }

            // get the PDFSharePathToday from the Exec-config.
            docConfig = BALExecutionConfigurationObj.GetConfig_By_Key("PDFSharePathToday");
            if (docConfig == null)
            {
                Console.WriteLine("OnBase data source not found in the system. Application terminated.");
                return -1;
            }
            else
            {
                this.PathToSaveCharts = docConfig["value"].AsString;
            }
            return 1;
        }

        void ConnectOnBase()
        {
            try
            {
                // Load Balancer OnBase-API.
                // URL = "http://208.84.217.109/Appserver64AA/Service.asmx";

                OnBaseAuthenticationProperties props = Hyland.Unity.Application.CreateOnBaseAuthenticationProperties(URL, LoginID, Password, DataSource);
                props.LicenseType = LicenseType.Default;
                props.InstitutionID = institutionID;
                app = Hyland.Unity.Application.Connect(props);
            }
            catch (Exception ex)
            {
                app = null;
            }

            this.OnBaseAppObj = app;
        }

        void DisconnectOnBase()
        {
            if (app != null)
            {
                app.Disconnect();
            }
        }
    }
}
