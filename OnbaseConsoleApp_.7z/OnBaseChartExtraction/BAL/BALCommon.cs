﻿using MongoDB.Bson;
using OnBaseChartExtraction.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnBaseChartExtraction.BAL
{
    class BALCommon
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        string DBName = ConfigurationManager.AppSettings["DBName"];
        DALCommon Obj;

        public BALCommon()
        {
            Obj = new DALCommon(ConnectionString, DBName);
        }

        public List<BsonDocument> GetExtractionPendingDocuments()
        {
            List<BsonDocument> result = new List<BsonDocument>();
            List<BsonDocument> ExtractionPendingDocuments = Obj.GetExtractionPendingDocuments();
            if (ExtractionPendingDocuments != null && ExtractionPendingDocuments.Count > 0)
            {
                foreach (var each_doc in ExtractionPendingDocuments)
                {
                    DateTime TransitionDate = new DateTime();
                    if (each_doc["TransitionDate"].AsString.Length > 0)
                    {
                        var TransitionDateStr = each_doc["TransitionDate"].AsString;
                        try
                        {
                            TransitionDate = Convert.ToDateTime(each_doc["TransitionDate"].AsString);
                        }
                        catch (Exception)
                        {
                            string only_date = TransitionDateStr.Split(' ')[0];
                            string only_time = TransitionDateStr.Split(' ')[1];
                            string am_pm = TransitionDateStr.Split(' ')[2];
                            string newTransitionDate = "";
                            char delimiter = ' ';
                            if (only_date.IndexOf('-') >= 0)
                            {
                                delimiter = '-';
                            }
                            else if (only_date.IndexOf('/') >= 0)
                            {
                                delimiter = '/';
                            }
                            int numberAtFirstIndex = Convert.ToInt32(only_date.Split(delimiter)[0]);
                            int numberAtSecondIndex = Convert.ToInt32(only_date.Split(delimiter)[1]);
                            newTransitionDate = numberAtSecondIndex + delimiter.ToString() + numberAtFirstIndex + delimiter.ToString() + only_date.Split(delimiter)[2] + " " + only_time + " " + am_pm;
                            TransitionDate = Convert.ToDateTime(newTransitionDate);
                        }
                        
                    }
                    each_doc.Add("TransitionDateConverted", TransitionDate);
                    result.Add(each_doc);
                }
            }
            return result;
        }

        public BsonDocument GetFirstExtractionPendingDocument()
        {
            List<BsonDocument> result = new List<BsonDocument>();
            List<BsonDocument> ExtractionPendingDocuments = Obj.GetExtractionPendingDocuments();
            if (ExtractionPendingDocuments != null && ExtractionPendingDocuments.Count > 0)
            {
                foreach (var each_doc in ExtractionPendingDocuments)
                {
                    DateTime TransitionDate = new DateTime();
                    if (each_doc["TransitionDate"].AsString.Length > 0)
                    {
                        var TransitionDateStr = each_doc["TransitionDate"].AsString;
                        try
                        {
                            TransitionDate = Convert.ToDateTime(each_doc["TransitionDate"].AsString);
                        }
                        catch (Exception)
                        {
                            string only_date = TransitionDateStr.Split(' ')[0];
                            string only_time = TransitionDateStr.Split(' ')[1];
                            string am_pm = TransitionDateStr.Split(' ')[2];
                            string newTransitionDate = "";
                            char delimiter = ' ';
                            if (only_date.IndexOf('-') >= 0)
                            {
                                delimiter = '-';
                            }
                            else if (only_date.IndexOf('/') >= 0)
                            {
                                delimiter = '/';
                            }
                            int numberAtFirstIndex = Convert.ToInt32(only_date.Split(delimiter)[0]);
                            int numberAtSecondIndex = Convert.ToInt32(only_date.Split(delimiter)[1]);
                            newTransitionDate = numberAtSecondIndex + delimiter.ToString() + numberAtFirstIndex + delimiter.ToString() + only_date.Split(delimiter)[2] + " " + only_time + " " + am_pm;
                            TransitionDate = Convert.ToDateTime(newTransitionDate);
                        }

                    }
                    each_doc.Add("TransitionDateConverted", TransitionDate);
                    result.Add(each_doc);
                }
            }
            // SELECT TOP 1 * FROM <list> ORDER BY TransitionDateConverted;
            return result.OrderBy(row => row["TransitionDateConverted"].AsBsonDateTime).FirstOrDefault();
        }

        public bool LockChartExtractionStatus(string TESBatchNo)
        {
            return Obj.LockChartExtractionStatus(TESBatchNo, "Locked");
        }

        public bool FinalizeCognosReportBatch(string TESBatchNo, string ChartExtractionStatus, int OnBaseChartCount, string Remarks)
        {
            return Obj.FinalizeCognosReportBatch(TESBatchNo, ChartExtractionStatus, OnBaseChartCount, Remarks);
        }

        public bool AddCognosBatchEncounter(BsonDocument Data)
        {
            string TESBatchNo = Data["TESBatchNo"].AsString;
            string EncounterNo = Data["EncounterNo"].AsString;
            bool IsCPTCodesExtracted = Obj.CPTCodesExtracted(TESBatchNo, EncounterNo);
            if(IsCPTCodesExtracted)
            {
                Data.Add("CPTCodesExtractionStatus", "Completed");
            }
            else
            {
                Data.Add("CPTCodesExtractionStatus", "Pending");
            }
            return Obj.AddCognosBatchEncounter(Data);
        }

        public List<BsonDocument> GetFacilityMasterWithDocTypes()
        {
            return Obj.GetFacilityMasterWithDocTypes();
        }
        public List<BsonDocument> GetBatchTypeKeyWordSearchConfig()
        {
            return Obj.GetBatchTypeKeyWordSearchConfig();
        }

        public List<BsonDocument> GetDocTypeConfig()
        {
            return Obj.GetDocTypeConfig();
        }

        public List<BsonDocument> GetKeyWordTypeConfig(int DocTypeID)
        {
            return Obj.GetKeyWordTypeConfig(DocTypeID);
        }

        public List<BsonDocument> GetColumnsListForCognosBatch(int DocTypeID)
        {
            List<BsonDocument> result = Obj.GetColumnsListForCognosBatch(DocTypeID);
            return result;
        }

        public void WriteLog(BsonDocument LogDocument)
        {
            Obj.WriteLog(LogDocument);
        }
        public void ConvertFloatToInt()
        {
            Obj.ConvertFloatToInt();
        }
    }
}
