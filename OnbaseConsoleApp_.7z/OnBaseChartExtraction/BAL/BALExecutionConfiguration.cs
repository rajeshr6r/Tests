﻿using MongoDB.Bson;
using OnBaseChartExtraction.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnBaseChartExtraction.BAL
{
   public class BALExecutionConfiguration
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        string DBName = ConfigurationManager.AppSettings["DBName"];
        DALExecutionConfiguration Obj;

        public BALExecutionConfiguration()
        {
            Obj = new DALExecutionConfiguration(ConnectionString, DBName);
        }
        public BsonDocument GetConfig_By_Key(string prm_keyname)
        {
            return Obj.GetConfig_By_Key(prm_keyname);
        }

        public List<BsonDocument> GetAllConfig()
        {
            return Obj.GetAllConfig();
        }
    }
}
